"""
Agoda Price Monitor
--------------------
予約金額より安い料金が見つかったらメールで通知します。
"""

import json
import os
import smtplib
import time
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

from playwright.sync_api import sync_playwright


# ======================================================
# 設定: bookings.json で管理（このファイルは直接編集しない）
# ======================================================

BOOKINGS_FILE = Path(__file__).parent / "bookings.json"
PRICES_FILE = Path(__file__).parent / "prices_history.json"

# メール設定（GitHub Secrets から環境変数で読み込み）
GMAIL_USER = os.environ.get("GMAIL_USER", "")
GMAIL_APP_PASSWORD = os.environ.get("GMAIL_APP_PASSWORD", "")
NOTIFY_TO = os.environ.get("NOTIFY_TO", GMAIL_USER)


# ======================================================
# 料金取得
# ======================================================

def fetch_price(page, url: str) -> float | None:
    """AgodaのURLから現在の料金を取得する"""
    try:
        page.goto(url, timeout=30000, wait_until="domcontentloaded")
        time.sleep(3)  # 動的コンテンツの読み込みを待つ

        # Agodaの料金セレクター（複数パターン試行）
        selectors = [
            '[data-selenium="hotel-room-price"]',
            '.PropertyRoomTypeList__roomPrice',
            '[class*="roomPrice"]',
            '[class*="price-text"]',
            'span[class*="Price"]',
        ]

        for sel in selectors:
            elements = page.query_selector_all(sel)
            for el in elements:
                text = el.inner_text().strip()
                # "¥45,000" や "JPY 45,000" などから数字を抽出
                import re
                nums = re.findall(r'[\d,]+', text.replace(',', ''))
                for n in nums:
                    val = float(n.replace(',', ''))
                    if val > 1000:  # 最低1,000円以上の値のみ
                        return val

        print(f"  [警告] 料金が見つかりませんでした: {url}")
        return None

    except Exception as e:
        print(f"  [エラー] {url}: {e}")
        return None


# ======================================================
# メール通知
# ======================================================

def send_email(subject: str, body_html: str):
    """Gmail でメール送信"""
    if not GMAIL_USER or not GMAIL_APP_PASSWORD:
        print("[通知] メール設定なし → コンソール出力のみ")
        print(f"件名: {subject}")
        return

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = GMAIL_USER
    msg["To"] = NOTIFY_TO
    msg.attach(MIMEText(body_html, "html", "utf-8"))

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(GMAIL_USER, GMAIL_APP_PASSWORD)
        server.sendmail(GMAIL_USER, NOTIFY_TO, msg.as_string())
    print(f"  [通知] メール送信完了 → {NOTIFY_TO}")


def build_email_html(alerts: list[dict]) -> str:
    rows = ""
    for a in alerts:
        saved = a["booked"] - a["current"]
        rows += f"""
        <tr>
          <td style="padding:12px 16px; border-bottom:1px solid #eee;">
            <strong>{a['hotel']}</strong><br>
            <span style="font-size:12px; color:#666;">{a['checkin']} 〜 {a['checkout']} / {a['room']}</span>
          </td>
          <td style="padding:12px 16px; border-bottom:1px solid #eee; text-align:right; color:#888; text-decoration:line-through;">
            ¥{a['booked']:,.0f}
          </td>
          <td style="padding:12px 16px; border-bottom:1px solid #eee; text-align:right; color:#2d7a3a; font-weight:bold; font-size:18px;">
            ¥{a['current']:,.0f}
          </td>
          <td style="padding:12px 16px; border-bottom:1px solid #eee; text-align:right; color:#2d7a3a;">
            ¥{saved:,.0f} お得
          </td>
          <td style="padding:12px 16px; border-bottom:1px solid #eee;">
            <a href="{a['url']}" style="color:#1a56db;">Agodaで確認 →</a>
          </td>
        </tr>"""

    return f"""
    <html><body style="font-family: sans-serif; color: #333; max-width: 700px; margin: auto;">
      <div style="background:#1a56db; color:white; padding:20px 24px; border-radius:8px 8px 0 0;">
        <h2 style="margin:0;">🏨 Agoda 料金値下がりアラート</h2>
        <p style="margin:4px 0 0; opacity:0.85; font-size:14px;">{datetime.now().strftime('%Y年%m月%d日 %H:%M')} 更新</p>
      </div>
      <div style="background:#f0fdf4; border:1px solid #bbf7d0; padding:16px 24px; margin:0;">
        <strong style="color:#166534;">✅ {len(alerts)}件</strong>の予約で料金が下がっています。キャンセル・再予約をご検討ください。
      </div>
      <table style="width:100%; border-collapse:collapse; background:white; border:1px solid #eee; border-top:none;">
        <thead>
          <tr style="background:#f8f9fa; font-size:12px; color:#666; text-transform:uppercase;">
            <th style="padding:10px 16px; text-align:left;">ホテル</th>
            <th style="padding:10px 16px; text-align:right;">予約金額</th>
            <th style="padding:10px 16px; text-align:right;">現在の料金</th>
            <th style="padding:10px 16px; text-align:right;">差額</th>
            <th style="padding:10px 16px; text-align:left;">リンク</th>
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
      <p style="font-size:12px; color:#999; padding:16px;">
        このメールはAgoda料金監視スクリプトによって自動送信されました。
      </p>
    </body></html>
    """


# ======================================================
# メイン処理
# ======================================================

def load_bookings() -> list[dict]:
    if not BOOKINGS_FILE.exists():
        print(f"[エラー] {BOOKINGS_FILE} が見つかりません")
        return []
    with open(BOOKINGS_FILE) as f:
        return json.load(f)


def load_history() -> dict:
    if PRICES_FILE.exists():
        with open(PRICES_FILE) as f:
            return json.load(f)
    return {}


def save_history(history: dict):
    with open(PRICES_FILE, "w") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)


def main():
    bookings = load_bookings()
    if not bookings:
        print("監視する予約がありません。bookings.json を確認してください。")
        return

    history = load_history()
    alerts = []
    now_str = datetime.now().isoformat()

    print(f"\n{'='*50}")
    print(f"Agoda 料金チェック開始: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"対象: {len(bookings)}件")
    print(f"{'='*50}\n")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            locale="ja-JP",
        )
        page = context.new_page()

        for b in bookings:
            bid = b["id"]
            print(f"チェック中: {b['hotel']} ({b['checkin']} 〜 {b['checkout']})")

            current_price = fetch_price(page, b["url"])

            if current_price is None:
                print(f"  → 料金取得失敗、スキップ\n")
                continue

            booked = b["booked_price"]
            threshold = b.get("threshold", 1000)
            diff = booked - current_price

            print(f"  予約金額: ¥{booked:,.0f}")
            print(f"  現在の料金: ¥{current_price:,.0f}")
            print(f"  差額: ¥{diff:,.0f}")

            # 履歴を保存
            if bid not in history:
                history[bid] = []
            history[bid].append({"date": now_str, "price": current_price})

            if diff >= threshold:
                print(f"  ✅ アラート！ ¥{diff:,.0f} 安くなっています")
                alerts.append({
                    "hotel": b["hotel"],
                    "checkin": b["checkin"],
                    "checkout": b["checkout"],
                    "room": b.get("room", ""),
                    "url": b["url"],
                    "booked": booked,
                    "current": current_price,
                })
            else:
                print(f"  → 変化なし（閾値: ¥{threshold:,.0f}）")
            print()

            time.sleep(2)  # サーバー負荷軽減

        browser.close()

    save_history(history)

    if alerts:
        print(f"\n{'='*50}")
        print(f"📧 {len(alerts)}件のアラートをメール送信します...")
        send_email(
            subject=f"【Agoda】{len(alerts)}件の料金が値下がりしています",
            body_html=build_email_html(alerts),
        )
    else:
        print("値下がりなし。次回チェックを待ちます。")

    print(f"\nチェック完了: {datetime.now().strftime('%Y-%m-%d %H:%M')}")


if __name__ == "__main__":
    main()
